from .BiciMad import BiciMad

__all__ = ["BiciMad"]
