from decorators import check_args_types

from .BiciMad import BiciMad

__all__ = ["BiciMad", "check_args_types"]
