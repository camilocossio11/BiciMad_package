from .types_decorator import check_args_types

__all__ = ["check_args_types"]
